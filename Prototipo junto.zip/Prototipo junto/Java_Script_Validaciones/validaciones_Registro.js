// Selección de formulario e inputs
const formulario = document.querySelector(".login");
const inputs = document.querySelectorAll(".login input");

// Expresiones regulares
const expresiones = {
    login_email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,  // correo válido
    password: /^.{6,20}$/                       // 6 a 20 caracteres
};

// Validación de campos
const validarFormulario = (e) => {
    switch (e.target.name) {
        case "login_email":
            if (expresiones.login_email.test(e.target.value)) {
                e.target.classList.remove("input-error");
                e.target.classList.add("input-ok");
            } else {
                e.target.classList.add("input-error");
                e.target.classList.remove("input-ok");
            }
        break;

        case "login-pass":
            if (expresiones.password.test(e.target.value)) {
                e.target.classList.remove("input-error");
                e.target.classList.add("input-ok");
            } else {
                e.target.classList.add("input-error");
                e.target.classList.remove("input-ok");
            }
        break;
    }
};

// Eventos en inputs
inputs.forEach((input) => {
    input.addEventListener("keyup", validarFormulario);
    input.addEventListener("blur", validarFormulario);
});

// Manejo del submit
formulario.addEventListener("submit", (e) => {
    e.preventDefault();

    const email = document.getElementById("login_email").value;
    const pass = document.getElementById("login-pass").value;

    if (!expresiones.login_email.test(email)) {
        alert("⚠️ Correo inválido");
        return;
    }

    if (!expresiones.password.test(pass)) {
        alert("⚠️ La contraseña debe tener entre 6 y 20 caracteres");
        return;
    }

    alert("✅ Inicio de sesión correcto");
    formulario.reset();
});     

