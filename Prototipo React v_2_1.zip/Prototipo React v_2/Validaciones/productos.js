// src/data/productos.js

export const productos = [
  {
    id: 1,
    nombre: "Elden Ring",
    plataforma: "PS5",
    precio: 59990,
    precioOriginal: 59990,
    categoria: "rpg",
    imagen: "/img/Elden-Ring.webp",
    descripcion:
      "Un juego de rol de acción en un mundo fantástico creado por Hidetaka Miyazaki y George R. R. Martin. Explora las Tierras Intermedias y descubre sus secretos.",
  },
  {
    id: 2,
    nombre: "The Legend of Zelda: Tears of the Kingdom",
    plataforma: "Switch",
    precio: 59990,
    precioOriginal: 59990,
    categoria: "aventura",
    imagen: "/img/Zelda.webp",
    descripcion:
      "La esperada secuela de Breath of the Wild. Únete a Link en una nueva aventura para rescatar a Zelda y salvar Hyrule de una amenaza ancestral.",
  },
  {
    id: 3,
    nombre: "Call of Duty: Modern Warfare II",
    plataforma: "Xbox Series X",
    precio: 69990,
    precioOriginal: 69990,
    categoria: "accion",
    imagen: "/img/COD-MW.jpg",
    descripcion:
      "Vuelve la icónica serie Modern Warfare con una campaña intensa, un multijugador revolucionario y un modo cooperativo especial de operaciones tácticas.",
  },
  {
    id: 4,
    nombre: "FIFA 23",
    plataforma: "PS5",
    precio: 59990,
    precioOriginal: 59990,
    categoria: "deportes",
    imagen: "/img/FIFA-23.jpg",
    descripcion:
      "El último juego de la saga FIFA con HyperMotion2 Technology, que ofrece realismos sin precedentes en cada partido y la FIFA World Cup™ masculina y femenina.",
  },
  {
    id: 5,
    nombre: "Cyberpunk 2077",
    plataforma: "PC",
    precio: 29990,
    precioOriginal: 49990,
    categoria: "rpg",
    imagen: "/img/Cyberpunk.webp",
    descripcion:
      "Un RPG de mundo abierto situado en Night City, una megalópolis obsesionada con el poder, el glamur y las modificaciones corporales. Juega como un mercenario cyberpunk.",
  },
  {
    id: 6,
    nombre: "Horizon Forbidden West",
    plataforma: "PS5",
    precio: 49990,
    precioOriginal: 69990,
    categoria: "aventura",
    imagen: "/img/Horizon.webp",
    descripcion:
      "Únete a Aloy mientras se aventura en el Oeste Prohibido, una frontera majestuosa pero peligrosa que esconde nuevas misteriosas amenazas.",
  },
  {
    id: 7,
    nombre: "Halo Infinite",
    plataforma: "Xbox Series X",
    precio: 39990,
    precioOriginal: 59990,
    categoria: "accion",
    imagen: "/img/Halo.jpg",
    descripcion:
      "La última entrega de la franquicia icónica de Xbox. El Jefe Maestro está de regreso para enfrentar el desafío más grande hasta ahora para salvar la humanidad.",
  },
  {
    id: 8,
    nombre: "Animal Crossing: New Horizons",
    plataforma: "Switch",
    precio: 44990,
    precioOriginal: 54990,
    categoria: "aventura",
    imagen: "/img/Animal-Crossing.webp",
    descripcion:
      "Crea tu propia isla paradisíaca, personaliza tu comunidad, tu casa y disfruta de una vida tranquila llena de actividades y personajes encantadores.",
  },
  {
    id: 9,
    nombre: "Final Fantasy XVI",
    plataforma: "PS5",
    precio: 69990,
    precioOriginal: 69990,
    categoria: "rpg",
    imagen: "/img/Final-Fantasy.webp",
    descripcion:
      "Un nuevo capítulo de la legendaria saga de RPG. Sumérgete en un mundo de magia, guerra y conflicto mientras descubres el destino de los Eikons.",
  },
  {
    id: 10,
    nombre: "Starfield",
    plataforma: "Xbox Series X",
    precio: 69990,
    precioOriginal: 69990,
    categoria: "rpg",
    imagen: "/img/Starfield.jpg",
    descripcion:
      "El primer universo nuevo en 25 años de Bethesda Game Studios. Explora las estrellas y descubre la mayor misterio de la humanidad en este épico RPG.",
  },
  {
    id: 11,
    nombre: "The Legend of Zelda: Echoes of Wisdom",
    plataforma: "Switch",
    precio: 59990,
    precioOriginal: 59990,
    categoria: "aventura",
    imagen: "/img/Zelda-Echoes.webp",
    descripcion:
      "Una nueva aventura en el universo de Zelda donde por primera vez podrás jugar como la princesa Zelda, utilizando ecos mágicos para resolver puzzles y combatir enemigos.",
  },
  {
    id: 12,
    nombre: "Spider-Man 2",
    plataforma: "PS5",
    precio: 69990,
    precioOriginal: 69990,
    categoria: "accion",
    imagen: "/img/SpiderMan.avif",
    descripcion:
      "Juega como Peter Parker y Miles Morales mientras protegen Nueva York de nuevos y peligrosos villanos. Experimenta habilidades arácnidas mejoradas y un mundo abierto más grande.",
  },
];

export const categorias = {
  "mas-buscados": [1, 2, 3, 4],
  ofertas: [5, 6, 7, 8],
  reservas: [9, 10, 11, 12],
};
