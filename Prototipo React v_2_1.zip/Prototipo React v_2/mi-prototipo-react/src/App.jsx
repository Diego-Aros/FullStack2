import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// CLIENTE
import PaginaP from "./assets/views/Vista Cliente/paginaP";
import Productos from "./assets/views/Vista Cliente/productos";
import Nosotros from "./assets/views/Vista Cliente/nosotros";
import Detalle from "./assets/views/Vista Cliente/detalle";
import Contacto from "./assets/views/Vista Cliente/contacto";
import Comunidad from "./assets/views/Vista Cliente/comunidad";
import IniRegUsuario from "./assets/views/Vista Cliente/ini_reg_usuario";

// VENDEDOR
import CrearProductoVendedor from "./assets/views/Vista Vendedor/crearProductoVendedor";
import EdicionProductoVendedor from "./assets/views/Vista Vendedor/edicionProductosVendedor";
import PrincipalVendedor from "./assets/views/Vista Vendedor/pPrincipalVendedor";
import ProductosVendedor from "./assets/views/Vista Vendedor/ProductosVendedor";
import VerProductosVendedor from "./assets/views/Vista Vendedor/verProductosVendedor";

// ADMINISTRADOR
import CrearProductoAdmin from "./assets/views/Vista Administrador/crearProductoAdmin";
import EdicionProductosAdmin from "./assets/views/Vista Administrador/edicionProductosAdmin";
import EditarUsuarios from "./assets/views/Vista Administrador/editarUsuarios";
import PrincipalAdmin from "./assets/views/Vista Administrador/pPrincipalAdmin";
import ProductosAdmin from "./assets/views/Vista Administrador/productosAdmin";
import RegistroUsuarios from "./assets/views/Vista Administrador/registroUsuarios";
import Usuarios from "./assets/views/Vista Administrador/usuarios";
import VerProductosAdmin from "./assets/views/Vista Administrador/verProductosAdmin";
import VerUsuarios from "./assets/views/Vista Administrador/verUsuario";

function App() {
  return (
    <Router>
      <Routes>
        {/* CLIENTE */}
        <Route path="/" element={<PaginaP />} />
        <Route path="/productos" element={<Productos />} />
        <Route path="/nosotros" element={<Nosotros />} />
        <Route path="/detalle" element={<Detalle />} />
        <Route path="/contacto" element={<Contacto />} />
        <Route path="/comunidad" element={<Comunidad />} />
        <Route path="/login" element={<IniRegUsuario />} />

        {/* VENDEDOR */}
        <Route path="/vendedor" element={<PrincipalVendedor />} />
        <Route path="/vendedor/productos" element={<ProductosVendedor />} />
        <Route path="/vendedor/crear-producto" element={<CrearProductoVendedor />} />
        <Route path="/vendedor/editar-producto" element={<EdicionProductoVendedor />} />
        <Route path="/vendedor/ver-producto" element={<VerProductosVendedor />} />

        {/* ADMINISTRADOR */}
        <Route path="/admin" element={<PrincipalAdmin />} />
        <Route path="/admin/productos" element={<ProductosAdmin />} />
        <Route path="/admin/crear-producto" element={<CrearProductoAdmin />} />
        <Route path="/admin/editar-producto" element={<EdicionProductosAdmin />} />
        <Route path="/admin/ver-producto" element={<VerProductosAdmin />} />
        <Route path="/admin/usuarios" element={<Usuarios />} />
        <Route path="/admin/registrar-usuario" element={<RegistroUsuarios />} />
        <Route path="/admin/editar-usuario" element={<EditarUsuarios />} />
        <Route path="/admin/ver-usuario" element={<VerUsuarios />} />
      </Routes>
    </Router>
  );
}

export default App;
