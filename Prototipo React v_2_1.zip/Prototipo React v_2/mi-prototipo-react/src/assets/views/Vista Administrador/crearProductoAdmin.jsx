import React, { useState } from "react";
import "./styleAdministrador.css";

export default function CrearProductoAdmin() {
  // Estados para los campos del formulario
  const [formData, setFormData] = useState({
    nombre: "",
    categoria: "",
    precio: "",
    stock: "",
    descripcion: "",
  });

  // Maneja cambios en los inputs
  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData({ ...formData, [id]: value });
  };

  // Simula el envío del formulario
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Producto creado:", formData);
    alert("✅ Producto guardado correctamente");
  };

  return (
    <div className="admin-layout">
      {/* Sidebar */}
      <div className="sidebar">
        <div>
          <h2>GameSearch</h2>
          <div className="menu">
            <a href="pPrincipalAdmin.html" className="active">
              Inicio
            </a>
            <a href="productosAdmin.html">🎮 Productos</a>
            <a href="usuarios.html">👨‍💼 Empleados</a>
          </div>
        </div>
        <div className="footer">
          <a href="#">👤 Perfil</a>
        </div>
      </div>

      {/* Contenido principal */}
      <main className="main-content">
        <header>
          <h1>Crear Nuevo Producto</h1>
        </header>

        <form className="formulario" id="formulario" onSubmit={handleSubmit}>
          <div id="formulario_nombre" className="nombre">
            <label htmlFor="nombre">Nombre</label>
            <div className="formulario__grupo-input">
              <input
                type="text"
                className="formulario__input"
                id="nombre"
                placeholder="Ej: Mario Odyssey"
                value={formData.nombre}
                onChange={handleChange}
              />
            </div>
            <p className="error" id="error-nombre"></p>
          </div>

          <div id="formulario_categoria" className="categoria">
            <label htmlFor="categoria">Categoría</label>
            <div className="formulario__grupo-input">
              <input
                type="text"
                className="formulario__input"
                id="categoria"
                placeholder="Ej: Nintendo Switch"
                value={formData.categoria}
                onChange={handleChange}
              />
            </div>
            <p className="error" id="error-categoria"></p>
          </div>

          <div id="formulario_precio" className="precio">
            <label htmlFor="precio">Precio</label>
            <div className="formulario__grupo-input">
              <input
                type="number"
                className="formulario__input"
                id="precio"
                placeholder="Ej: 299.99"
                value={formData.precio}
                onChange={handleChange}
              />
            </div>
            <p className="error" id="error-precio"></p>
          </div>

          <div id="formulario_stock" className="stock">
            <label htmlFor="stock">Stock</label>
            <div className="formulario__grupo-input">
              <input
                type="number"
                className="formulario__input"
                id="stock"
                placeholder="Ej: 15"
                value={formData.stock}
                onChange={handleChange}
              />
            </div>
            <p className="error" id="error-stock"></p>
          </div>

          <div id="descripcion" className="descripcion">
            <label htmlFor="descripcion">Descripción</label>
            <textarea
              id="descripcion"
              rows="4"
              placeholder="Escribe una breve descripción del producto..."
              value={formData.descripcion}
              onChange={handleChange}
            ></textarea>
          </div>

          <div id="submit" className="submit">
            <button type="submit" className="btn-primary">
              Guardar Producto
            </button>
            <a href="productosAdmin.html" className="btn-secondary">
              Cancelar
            </a>
          </div>
        </form>
      </main>
    </div>
  );
}
