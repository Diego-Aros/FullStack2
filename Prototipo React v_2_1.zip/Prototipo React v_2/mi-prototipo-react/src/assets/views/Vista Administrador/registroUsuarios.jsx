import React from "react";
import "./styleAdministrador.css";

export default function RegistroUsuarios() {
  return (
    <div className="admin-layout">
      {/* Sidebar */}
      <div className="sidebar">
        <div>
          <h2>GameSearch</h2>
          <div className="menu">
            <a href="pPrincipalAdmin.html" className="active">inicio</a>
            <a href="productosAdmin.html">🎮 Productos</a>
            <a href="usuarios.html">👨‍💼 Empleados</a>
          </div>
        </div>
        <div className="footer">
          <a href="#">👤 Perfil</a>
        </div>
      </div>

      {/* Contenido principal */}
      <div className="main">
        <h1>NUEVO USUARIO</h1>

        <div className="form-container">
          <h2>Registro de usuario</h2>

          <form className="formulario" method="post">
            {/* RUN */}
            <div id="formulario_run" className="run">
              <label htmlFor="run">RUN</label>
              <div className="formulario__grupo-input">
                <input
                  type="text"
                  className="formulario__input"
                  id="run"
                  name="run"
                  required
                />
              </div>
              <p className="error" id="error-run"></p>
            </div>

            {/* Nombre */}
            <div id="formulario_nombre" className="nombre">
              <label htmlFor="nombre">Nombre completo</label>
              <div className="formulario__grupo-input">
                <input
                  type="text"
                  className="formulario__input"
                  id="nombre"
                  name="nombre"
                  required
                />
              </div>
              <p className="error" id="error-nombre"></p>
            </div>

            {/* Correo */}
            <div id="formulario_correo" className="correo">
              <label htmlFor="correo">Correo</label>
              <div className="formulario__grupo-input">
                <input
                  type="email"
                  className="formulario__input"
                  id="correo"
                  name="correo"
                  required
                />
              </div>
              <p className="error" id="error-correo"></p>
            </div>

            {/* Usuario */}
            <div id="formulario_usuario" className="usuario">
              <label htmlFor="usuario">Usuario</label>
              <div className="formulario__grupo-input">
                <input
                  type="text"
                  className="formulario__input"
                  id="usuario"
                  name="usuario"
                  required
                />
              </div>
              <p className="error" id="error-usuario"></p>
            </div>

            {/* Contraseña */}
            <div id="formulario_password" className="password">
              <label htmlFor="password">Contraseña</label>
              <div className="formulario__grupo-input">
                <input
                  type="password"
                  className="formulario__input"
                  id="password"
                  name="password"
                  required
                />
              </div>
              <p className="error" id="error-password"></p>
            </div>

            {/* Confirmar */}
            <div id="formulario_confirmar" className="confirmar">
              <label htmlFor="confirmar">Confirmar contraseña</label>
              <div className="formulario__grupo-input">
                <input
                  type="password"
                  className="formulario__input"
                  id="confirmar"
                  name="confirmar"
                  required
                />
              </div>
              <p className="error" id="error-confirmar"></p>
            </div>

            {/* Teléfono */}
            <div id="formulario_telefono" className="telefono">
              <label htmlFor="telefono">Teléfono (opcional)</label>
              <input type="tel" id="telefono" name="telefono" />
              <p className="error" id="error-telefono"></p>
            </div>

            {/* Región y Comuna */}
            <div className="row">
              <select name="region" required>
                <option value="">-- Seleccione la región --</option>
                <option>Región Metropolitana de Santiago</option>
                <option>Región de Los Ángeles</option>
                <option>Región de Ñuble</option>
              </select>

              <select name="comuna" required>
                <option value="">-- Seleccione la comuna --</option>
              </select>
            </div>

            {/* Rol */}
            <div className="row">
              <select id="rol" name="tipoUsuario" required>
                <option value="">-- Seleccione el rol --</option>
                <option>Administrador</option>
                <option>Vendedor</option>
                <option>Cliente</option>
              </select>
            </div>

            <button type="submit">Registrar</button>
          </form>
        </div>
      </div>
    </div>
  );
}
