import React from "react";
import "./styleAdministrador.css";

export default function VerUsuario() {
  // En el futuro puedes reemplazar estos datos con props o datos de una API.
  const usuario = {
    id: 1,
    nombre: "Carlos Pérez",
    rol: "Administrador",
    email: "carlos@gamesearch.com",
    estado: "Activo",
  };

  return (
    <div className="admin-layout">
      {/* Sidebar */}
      <div className="sidebar">
        <div>
          <h2>GameSearch</h2>
          <div className="menu">
            <a href="pPrincipalAdmin.html" className="active">
              inicio
            </a>
            <a href="productosAdmin.html">🎮 Productos</a>
            <a href="usuarios.html" className="active">
              👨‍💼 Usuarios
            </a>
          </div>
        </div>
        <div className="footer">
          <a href="#">👤 Perfil</a>
        </div>
      </div>

      {/* Contenido principal */}
      <main className="main-content">
        <header>
          <h1>Detalles del Usuario</h1>
        </header>

        <div className="formulario">
          <p>
            <strong>ID:</strong> {usuario.id}
          </p>
          <p>
            <strong>Nombre:</strong> {usuario.nombre}
          </p>
          <p>
            <strong>Rol:</strong> {usuario.rol}
          </p>
          <p>
            <strong>Email:</strong> {usuario.email}
          </p>
          <p>
            <strong>Estado:</strong> {usuario.estado}
          </p>

          <a href="usuarios.html" className="btn-secondary">
            ⬅ Volver
          </a>
        </div>
      </main>
    </div>
  );
}
