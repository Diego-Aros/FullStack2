import React from "react";
import "./styleAdministrador.css";

export default function PPrincipalAdmin() {
  return (
    <div className="admin-layout">
      {/* Sidebar */}
      <div className="sidebar">
        <div>
          <h2>GameSearch</h2>
          <div className="menu">
            <a href="pPrincipalAdmin.html" className="active">
              Inicio
            </a>
            <a href="productosAdmin.html">🎮 Productos</a>
            <a href="usuarios.html">👨‍💼 Empleados</a>
          </div>
        </div>
        <div className="footer">
          <a href="#">👤 Perfil</a>
        </div>
      </div>

      {/* Contenido principal */}
      <div className="main">
        <h1>¡HOLA Administrador!</h1>
        <p>
          Bienvenido al panel de control de <strong>GameSearch</strong>.
        </p>
        <p>
          Aquí podrás gestionar órdenes, inventario, empleados, clientes y más.
        </p>
      </div>
    </div>
  );
}
