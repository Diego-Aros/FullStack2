import React, { useState } from "react";
import "./styleAdministrador.css";

export default function EdicionProductosAdmin() {
  // Estado inicial con los valores precargados del producto
  const [formData, setFormData] = useState({
    nombre: "Astro bot",
    categoria: "PlayStation 5",
    precio: "499.00",
    stock: "20",
    descripcion:
      "Astro, el jugador se embarca en una misión para salvar a los robots perdidos, recuperar piezas para la nave nodriza de PlayStation 5 y derrotar al alienígena Space Bully Nebulax, que destruyó la nave nodriza.",
  });

  // Manejo de cambios en los inputs
  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData({ ...formData, [id]: value });
  };

  // Simulación del envío de formulario
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Cambios guardados:", formData);
    alert("✅ Cambios guardados correctamente");
  };

  return (
    <div className="admin-layout">
      {/* Sidebar */}
      <div className="sidebar">
        <div>
          <h2>GameSearch</h2>
          <div className="menu">
            <a href="pPrincipalAdmin.html" className="active">
              Inicio
            </a>
            <a href="productosAdmin.html">🎮 Productos</a>
            <a href="usuarios.html">👨‍💼 Empleados</a>
          </div>
        </div>
        <div className="footer">
          <a href="#">👤 Perfil</a>
        </div>
      </div>

      {/* Contenido principal */}
      <main className="main-content">
        <header>
          <h1>Editar Producto</h1>
        </header>

        <form className="formulario" id="formulario" onSubmit={handleSubmit}>
          <div id="formulario_nombre" className="nombre">
            <label htmlFor="nombre">Nombre</label>
            <div className="formulario__grupo-input">
              <input
                type="text"
                className="formulario__input"
                id="nombre"
                value={formData.nombre}
                onChange={handleChange}
              />
            </div>
            <p className="error" id="error-nombre"></p>
          </div>

          <div id="formulario_categoria" className="categoria">
            <label htmlFor="categoria">Categoría</label>
            <div className="formulario__grupo-input">
              <input
                type="text"
                className="formulario__input"
                id="categoria"
                value={formData.categoria}
                onChange={handleChange}
              />
            </div>
            <p className="error" id="error-categoria"></p>
          </div>

          <div id="formulario_precio" className="precio">
            <label htmlFor="precio">Precio</label>
            <div className="formulario__grupo-input">
              <input
                type="number"
                className="formulario__input"
                id="precio"
                value={formData.precio}
                onChange={handleChange}
              />
            </div>
            <p className="error" id="error-precio"></p>
          </div>

          <div id="formulario_stock" className="stock">
            <label htmlFor="stock">Stock</label>
            <div className="formulario__grupo-input">
              <input
                type="number"
                className="formulario__input"
                id="stock"
                value={formData.stock}
                onChange={handleChange}
              />
            </div>
            <p className="error" id="error-stock"></p>
          </div>

          <div id="descripcion" className="descripcion">
            <label htmlFor="descripcion">Descripción</label>
            <textarea
              id="descripcion"
              rows="4"
              value={formData.descripcion}
              onChange={handleChange}
            ></textarea>
          </div>

          <div id="submit" className="submit">
            <button type="submit" className="btn-primary">
              Guardar Cambios
            </button>
            <a href="productosAdmin.html" className="btn-secondary">
              Cancelar
            </a>
          </div>
        </form>
      </main>
    </div>
  );
}
