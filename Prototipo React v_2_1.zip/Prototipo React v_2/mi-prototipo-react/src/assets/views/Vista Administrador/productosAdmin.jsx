import React from "react";
import "./styleAdministrador.css";

export default function ProductosAdmin() {
  return (
    <div className="admin-layout">
      {/* Sidebar */}
      <div className="sidebar">
        <div>
          <h2>GameSearch</h2>
          <div className="menu">
            <a href="pPrincipalAdmin.html" className="active">
              inicio
            </a>
            <a href="productosAdmin.html">🎮 Productos</a>
            <a href="usuarios.html">👨‍💼 Empleados</a>
          </div>
        </div>
        <div className="footer">
          <a href="#">👤 Perfil</a>
        </div>
      </div>

      {/* Contenido principal */}
      <main className="main-content">
        <header>
          <h1>Productos</h1>
          <a href="crearProductoAdmin.html" className="btn-primary">
            Nuevo Producto
          </a>
        </header>

        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Nombre</th>
              <th>Categoría</th>
              <th>Precio</th>
              <th>Stock</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {[
              ["P002", "Resident Evil 4 Remake", "Play 5", "$59.00", "50"],
              ["P003", "The Last of Us Part II", "Play 4", "$49.00", "35"],
              ["P004", "God of War Ragnarök", "Play 4", "$69.00", "40"],
              ["P005", "Elden Ring", "Xbox series x", "$59.00", "60"],
              ["P006", "Hogwarts Legacy", "Play 5", "$69.00", "25"],
              ["P007", "Cyberpunk 2077", "Play 5", "$39.00", "45"],
              ["P008", "Red Dead Redemption 2", "Play 4", "$59.00", "30"],
            ].map(([id, nombre, categoria, precio, stock]) => (
              <tr key={id}>
                <td>{id}</td>
                <td>{nombre}</td>
                <td>{categoria}</td>
                <td>{precio}</td>
                <td>{stock}</td>
                <td>
                  <a href="verProductosAdmin.html" className="btn-secondary">
                    Ver
                  </a>
                  <a
                    href="edicionProductosAdmin.html"
                    className="btn-warning"
                  >
                    Editar
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </main>
    </div>
  );
}
