import React, { useState } from "react";
import "./styleAdministrador.css";

export default function EditarUsuarios() {
  const [usuario, setUsuario] = useState({
    nombre: "Carlos Pérez",
    rol: "Administrador",
    email: "carlos@gamesearch.com",
    estado: "Activo",
  });

  // Manejar cambios en los inputs y selects
  const handleChange = (e) => {
    const { id, value } = e.target;
    setUsuario({ ...usuario, [id]: value });
  };

  // Envío del formulario
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Cambios guardados:", usuario);
    alert("✅ Cambios guardados correctamente");
  };

  return (
    <div className="admin-layout">
      {/* Sidebar */}
      <div className="sidebar">
        <div>
          <h2>GameSearch</h2>
          <div className="menu">
            <a href="pPrincipalAdmin.html" className="active">
              Inicio
            </a>
            <a href="productosAdmin.html">🎮 Productos</a>
            <a href="usuarios.html" className="active">
              👨‍💼 Usuarios
            </a>
          </div>
        </div>
        <div className="footer">
          <a href="#">👤 Perfil</a>
        </div>
      </div>

      {/* Contenido principal */}
      <main className="main-content">
        <header>
          <h1>Editar Usuario</h1>
        </header>

        <form className="formulario" onSubmit={handleSubmit}>
          <div id="formulario_nombre" className="nombre">
            <label htmlFor="nombre">Nombre</label>
            <div className="formulario__grupo-input">
              <input
                type="text"
                id="nombre"
                value={usuario.nombre}
                onChange={handleChange}
              />
            </div>
            <p className="error" id="error-nombre"></p>
          </div>

          <label htmlFor="rol">Rol</label>
          <select id="rol" value={usuario.rol} onChange={handleChange}>
            <option>Administrador</option>
            <option>Vendedor</option>
            <option>Cliente</option>
          </select>

          <div id="formulario_email" className="nombre">
            <label htmlFor="email">Correo Electrónico</label>
            <div className="formulario__grupo-input">
              <input
                type="email"
                id="email"
                value={usuario.email}
                onChange={handleChange}
              />
            </div>
            <p className="error" id="error-email"></p>
          </div>

          <label htmlFor="estado">Estado</label>
          <select id="estado" value={usuario.estado} onChange={handleChange}>
            <option>Activo</option>
            <option>Inactivo</option>
          </select>

          <div className="submit">
            <button type="submit" className="btn-primary">
              Guardar Cambios
            </button>
            <a href="usuarios.html" className="btn-secondary">
              Cancelar
            </a>
          </div>
        </form>
      </main>
    </div>
  );
}
