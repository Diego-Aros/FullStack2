import React from "react";
import "./styleAdministrador.css";

export default function Usuarios() {
  const usuarios = [
    { id: 1, nombre: "Carlos Pérez", rol: "Administrador", email: "carlos@gamesearch.com" },
    { id: 2, nombre: "María López", rol: "Vendedor", email: "maria@gamesearch.com" },
    { id: 3, nombre: "Juan Martínez", rol: "Cliente", email: "juan@gamesearch.com" },
    { id: 4, nombre: "Ana Torres", rol: "Vendedor", email: "ana@gamesearch.com" },
    { id: 5, nombre: "Luis Ramírez", rol: "Cliente", email: "luis@gamesearch.com" },
    { id: 6, nombre: "Fernanda Silva", rol: "Administrador", email: "fernanda@gamesearch.com" },
    { id: 7, nombre: "Diego Herrera", rol: "Vendedor", email: "diego@gamesearch.com" },
    { id: 8, nombre: "Paula Castro", rol: "Cliente", email: "paula@gamesearch.com" },
  ];

  return (
    <div className="admin-layout">
      {/* Sidebar */}
      <div className="sidebar">
        <div>
          <h2>GameSearch</h2>
          <div className="menu">
            <a href="pPrincipalAdmin.html" className="active">inicio</a>
            <a href="productosAdmin.html">🎮 Productos</a>
            <a href="usuarios.html" className="active">👨‍💼 Usuarios</a>
          </div>
        </div>
        <div className="footer">
          <a href="#">👤 Perfil</a>
        </div>
      </div>

      {/* Contenido principal */}
      <main className="main-content">
        <header>
          <h1>Lista de Usuarios</h1>
          <a href="registroUsuarios.html" className="btn-primary">Nuevo Usuario</a>
        </header>

        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Rol</th>
                <th>Email</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {usuarios.map((usuario) => (
                <tr key={usuario.id}>
                  <td>{usuario.id}</td>
                  <td>{usuario.nombre}</td>
                  <td>{usuario.rol}</td>
                  <td>{usuario.email}</td>
                  <td>
                    <a href="verUsuario.html" className="btn-primary">👁️ Ver</a>
                    <a href="editarUsuarios.html" className="btn-secondary">✏️ Editar</a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
