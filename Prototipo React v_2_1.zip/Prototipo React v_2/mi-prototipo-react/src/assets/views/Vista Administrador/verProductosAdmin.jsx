import React from "react";
import "./styleAdministrador.css";

export default function VerProductosAdmin() {
  // En una versión futura, podrías recibir estos datos por props o desde una API.
  const producto = {
    nombre: "PlayStation 5",
    categoria: "Consolas",
    precio: "$499.00",
    stock: 20,
    descripcion: "La consola de última generación de Sony con soporte para juegos en 4K.",
  };

  return (
    <div className="admin-layout">
      {/* Sidebar */}
      <div className="sidebar">
        <div>
          <h2>GameSearch</h2>
          <div className="menu">
            <a href="pPrincipalAdmin.html" className="active">inicio</a>
            <a href="productosAdmin.html">🎮 Productos</a>
            <a href="usuarios.html">👨‍💼 Empleados</a>
          </div>
        </div>
        <div className="footer">
          <a href="#">👤 Perfil</a>
        </div>
      </div>

      {/* Contenido principal */}
      <main className="main-content">
        <header>
          <h1>Detalle de Producto</h1>
        </header>

        <section className="detalle-producto">
          <h2>{producto.nombre}</h2>
          <p><strong>Categoría:</strong> {producto.categoria}</p>
          <p><strong>Precio:</strong> {producto.precio}</p>
          <p><strong>Stock:</strong> {producto.stock} unidades</p>
          <p><strong>Descripción:</strong> {producto.descripcion}</p>
        </section>

        <div className="acciones">
          <a href="productosAdmin.html" className="btn-secondary">Volver</a>
          <a href="edicionProductosAdmin.html" className="btn-warning">Editar</a>
        </div>
      </main>
    </div>
  );
}
