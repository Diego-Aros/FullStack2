import React from "react";
import "./styleVendedor.css";

export default function ProductosVendedor() {
  const productos = [
    {
      id: "P002",
      nombre: "Resident Evil 4 Remake",
      categoria: "Videojuegos",
      precio: "$59.00",
      stock: 50,
    },
    {
      id: "P003",
      nombre: "The Last of Us Part II",
      categoria: "Videojuegos",
      precio: "$49.00",
      stock: 35,
    },
    {
      id: "P004",
      nombre: "God of War Ragnarök",
      categoria: "Videojuegos",
      precio: "$69.00",
      stock: 40,
    },
  ];

  return (
    <div className="vendedor-layout">
      {/* Sidebar */}
      <div className="sidebar">
        <div>
          <h2>GameSearch</h2>
          <div className="menu">
            <a href="pPrincipalVendedor.html">Inicio</a>
            <a href="productosVendedor.html" className="active">
              🎮 Mis Productos
            </a>
          </div>
        </div>
        <div className="footer">
          <a href="#">👤 Perfil</a>
        </div>
      </div>

      {/* Contenido principal */}
      <main className="main-content">
        <header>
          <h1>Mis Productos</h1>
          <a href="crearProductoVendedor.html" className="btn-primary">
            ➕ Nuevo Producto
          </a>
        </header>

        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Nombre</th>
              <th>Categoría</th>
              <th>Precio</th>
              <th>Stock</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {productos.map((producto) => (
              <tr key={producto.id}>
                <td>{producto.id}</td>
                <td>{producto.nombre}</td>
                <td>{producto.categoria}</td>
                <td>{producto.precio}</td>
                <td>{producto.stock}</td>
                <td>
                  <a href="verProductosVendedor.html" className="btn-secondary">
                    Ver
                  </a>
                  <a href="edicionProductosVendedor.html" className="btn-warning">
                    Editar
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </main>
    </div>
  );
}
