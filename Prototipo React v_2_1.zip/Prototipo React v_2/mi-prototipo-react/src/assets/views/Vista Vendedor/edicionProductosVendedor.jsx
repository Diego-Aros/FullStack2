import React, { useState } from "react";
import "./styleVendedor.css";

export default function EdicionProductosVendedor() {
  const [form, setForm] = useState({
    nombre: "Astro bot",
    categoria: "PlayStation 5",
    precio: "499.00",
    stock: "20",
    descripcion:
      "Astro, el jugador se embarca en una misión para salvar a los robots perdidos, recuperar piezas para la nave nodriza de PlayStation 5 y derrotar al alienígena Space Bully Nebulax, que destruyó la nave nodriza"
  });

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.id]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Aquí podrías enviar los cambios a una API
    console.log("✅ Producto editado:", form);
    alert("Cambios guardados correctamente");
  };

  return (
    <div className="vendedor-layout">
      {/* Sidebar */}
      <div className="sidebar">
        <div>
          <h2>GameSearch</h2>
          <div className="menu">
            <a href="pPrincipalVendedor.html">Inicio</a>
            <a href="productosVendedor.html" className="active">
              🎮 Mis Productos
            </a>
          </div>
        </div>
        <div className="footer">
          <a href="#">👤 Perfil</a>
        </div>
      </div>

      {/* Main Content */}
      <main className="main-content">
        <header>
          <h1>Editar Producto</h1>
        </header>

        <form className="formulario" id="formulario" onSubmit={handleSubmit}>
          {/* Nombre */}
          <div id="formulario_nombre" className="nombre">
            <label htmlFor="nombre">Nombre</label>
            <div className="formulario__grupo-input">
              <input
                type="text"
                className="formulario__input"
                id="nombre"
                value={form.nombre}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          {/* Categoría */}
          <div id="formulario_categoria" className="categoria">
            <label htmlFor="categoria">Categoría</label>
            <div className="formulario__grupo-input">
              <input
                type="text"
                className="formulario__input"
                id="categoria"
                value={form.categoria}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          {/* Precio */}
          <div id="formulario_precio" className="precio">
            <label htmlFor="precio">Precio</label>
            <div className="formulario__grupo-input">
              <input
                type="number"
                className="formulario__input"
                id="precio"
                value={form.precio}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          {/* Stock */}
          <div id="formulario_stock" className="stock">
            <label htmlFor="stock">Stock</label>
            <div className="formulario__grupo-input">
              <input
                type="number"
                className="formulario__input"
                id="stock"
                value={form.stock}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          {/* Descripción */}
          <div id="descripcion" className="descripcion">
            <label htmlFor="descripcion">Descripción</label>
            <textarea
              id="descripcion"
              rows="4"
              value={form.descripcion}
              onChange={handleChange}
              required
            />
          </div>

          {/* Botones */}
          <div id="submit" className="submit">
            <button type="submit" className="btn-primary">
              Guardar Cambios
            </button>
            <a href="productosVendedor.html" className="btn-secondary">
              Cancelar
            </a>
          </div>
        </form>
      </main>
    </div>
  );
}
