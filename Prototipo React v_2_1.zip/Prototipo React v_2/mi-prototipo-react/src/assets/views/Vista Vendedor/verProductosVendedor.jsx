import React from "react";
import "./styleVendedor.css";

export default function VerProductosVendedor() {
  const producto = {
    nombre: "PlayStation 5",
    categoria: "Consolas",
    precio: "$499.00",
    stock: 20,
    descripcion:
      "La consola de última generación de Sony con soporte para juegos en 4K.",
  };

  return (
    <div className="vendedor-layout">
      {/* Sidebar */}
      <div className="sidebar">
        <div>
          <h2>GameSearch</h2>
          <div className="menu">
            <a href="pPrincipalVendedor.html">Inicio</a>
            <a href="productosVendedor.html" className="active">
              🎮 Mis Productos
            </a>
          </div>
        </div>
        <div className="footer">
          <a href="#">👤 Perfil</a>
        </div>
      </div>

      {/* Contenido principal */}
      <main className="main-content">
        <header>
          <h1>Detalle de Producto</h1>
        </header>

        <section className="detalle-producto">
          <h2>{producto.nombre}</h2>
          <p>
            <strong>Categoría:</strong> {producto.categoria}
          </p>
          <p>
            <strong>Precio:</strong> {producto.precio}
          </p>
          <p>
            <strong>Stock:</strong> {producto.stock} unidades
          </p>
          <p>
            <strong>Descripción:</strong> {producto.descripcion}
          </p>
        </section>

        <div className="botones-accion">
          <a href="productosVendedor.html" className="btn-secondary">
            Volver
          </a>
          <a href="edicionProductosVendedor.html" className="btn-warning">
            Editar
          </a>
        </div>
      </main>
    </div>
  );
}
