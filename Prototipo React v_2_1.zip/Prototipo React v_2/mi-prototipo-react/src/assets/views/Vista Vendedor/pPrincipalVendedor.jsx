import React from "react";
import "./styleVendedor.css";

export default function PPrincipalVendedor() {
  return (
    <div className="vendedor-layout">
      {/* Sidebar */}
      <div className="sidebar">
        <div>
          <h2>GameSearch</h2>
          <div className="menu">
            <a href="pPrincipalVendedor.html" className="active">
              Inicio
            </a>
            <a href="productosVendedor.html">🎮 Mis Productos</a>
          </div>
        </div>
        <div className="footer">
          <a href="#">👤 Perfil</a>
        </div>
      </div>

      {/* Contenido principal */}
      <div className="main">
        <h1>¡HOLA Vendedor!</h1>
        <p>
          Bienvenido al panel de gestión de <strong>GameSearch</strong>.
        </p>
        <p>
          Aquí podrás administrar tus productos y ver su estado en el
          inventario.
        </p>
      </div>
    </div>
  );
}
