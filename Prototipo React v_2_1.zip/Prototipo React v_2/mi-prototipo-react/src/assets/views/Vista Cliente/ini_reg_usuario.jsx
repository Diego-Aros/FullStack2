import React, { useState } from "react";
import "./style.css";

export default function IniRegUsuario() {
  const [rol, setRol] = useState("");

  const handleLoginSubmit = (e) => {
    e.preventDefault();
    if (rol === "vendedor") {
      window.location.href = "../Vista vendedor FS2/pPrincipalVendedor.html";
    } else if (rol === "admin") {
      window.location.href = "../Vista administradorFS2.V9.2/pPrincipalAdmin.html";
    } else {
      alert("Por favor selecciona un rol para continuar.");
    }
  };

  return (
    <div>
      {/* Header */}
      <header>
        <div className="logo">
          <strong>GameSearch</strong>
        </div>
        <nav className="menu">
          <a href="paginaP.html">Inicio</a>
          <a href="productos.html">Productos</a>
          <a href="nosotros.html">Nosotros</a>
          <a href="comunidad.html">Blogs</a>
          <a href="contacto.html">Contacto</a>
        </nav>
        <div className="search-bar">
          <input type="text" placeholder="Buscar" />
        </div>
        <nav className="menu">
          <a href="ini_reg_usuario.html">Acceder</a>
        </nav>
        <a
          href="#"
          className="carrito"
          style={{ marginLeft: "20px" }}
          onClick={(e) => {
            e.preventDefault();
            alert("Aquí debería abrir el carrito");
          }}
        >
          🛒 Carrito <span id="carrito-cantidad">0</span>
        </a>
      </header>

      {/* Main */}
      <main>
        <div className="auth-container">
          {/* Formulario de inicio de sesión */}
          <div className="login-container">
            <form id="login-form" className="login" onSubmit={handleLoginSubmit}>
              <h2>Iniciar Sesión</h2>

              <div style={{ display: "flex", flexDirection: "column", gap: "10px", marginBottom: "20px" }}>
                <button
                  type="button"
                  style={{ background: "#6ec1e4", color: "#181818", border: "none", padding: "8px", borderRadius: "4px", fontWeight: "bold", cursor: "pointer" }}
                  onClick={() => (window.location.href = "../Vista vendedor FS2/pPrincipalVendedor.html")}
                >
                  Entrar como Vendedor
                </button>
                <button
                  type="button"
                  style={{ background: "#6ec1e4", color: "#181818", border: "none", padding: "8px", borderRadius: "4px", fontWeight: "bold", cursor: "pointer" }}
                  onClick={() => (window.location.href = "../Vista administradorFS2.V9.2/pPrincipalAdmin.html")}
                >
                  Entrar como Administrador
                </button>
              </div>

              <div className="email">
                <label htmlFor="login-email">Correo:</label>
                <div className="email">
                  <input type="email" className="login__form-input" id="login-email" name="login-email" required />
                </div>
              </div>

              <div className="password">
                <label htmlFor="login-pass">Contraseña:</label>
                <div className="password">
                  <input type="password" className="login__form-input" id="login-pass" name="login-pass" required />
                </div>
              </div>

              <div className="rol">
                <label htmlFor="rol">Acceder como:</label>
                <select id="rol" name="rol" required value={rol} onChange={(e) => setRol(e.target.value)}>
                  <option value="">-- Selecciona --</option>
                  <option value="vendedor">Vendedor</option>
                  <option value="admin">Administrador</option>
                </select>
              </div>

              <button type="submit">Entrar</button>
            </form>
          </div>

          {/* Formulario de registro */}
          <form className="register-form">
            <h2>Registro de usuario</h2>

            <div className="nombre">
              <label htmlFor="reg-nombre">Nombre completo:</label>
              <div className="formulario__grupo-input">
                <input type="text" className="register__form-input" id="reg-nombre" name="reg-nombre" required />
              </div>
            </div>

            <div className="reg-run">
              <label htmlFor="reg-run">RUN:</label>
              <input type="text" id="reg-run" name="reg-run" required placeholder="Ej: 19011022K" />
            </div>

            <div className="reg-email">
              <label htmlFor="reg-email">Correo:</label>
              <div className="formulario__grupo-input">
                <input type="email" className="register__form-input" id="reg-email" name="reg-email" required />
              </div>
            </div>

            <label htmlFor="reg-pass">Contraseña:</label>
            <input type="password" className="register__form-input" id="reg-pass" name="reg-pass" required />

            <label htmlFor="reg-pass-confirm">Confirmar contraseña:</label>
            <input type="password" className="register__form-input" id="reg-pass-confirm" name="reg-pass-confirm" required />

            <label htmlFor="reg-telefono">Teléfono (opcional):</label>
            <input type="tel" id="reg-telefono" name="reg-telefono" />

            <div className="reg-fecha-nac">
              <label htmlFor="reg-fecha-nac">Fecha de nacimiento:</label>
              <input type="date" className="register__form-input" id="reg-fecha-nac" name="reg-fecha-nac" required />
            </div>

            <label htmlFor="pais">País:</label>
            <select name="pais" id="pais" required>
              <option value="">-- Seleccione el país --</option>
              <option value="chile">Chile</option>
              <option value="argentina">Argentina</option>
              <option value="mexico">México</option>
              <option value="espana">España</option>
            </select>

            <label htmlFor="ciudad">Ciudad:</label>
            <select name="ciudad" id="ciudad" required>
              <option value="">-- Seleccione la ciudad --</option>
              <option value="santiago">Santiago</option>
              <option value="buenosaires">Buenos Aires</option>
              <option value="cdmx">Ciudad de México</option>
              <option value="madrid">Madrid</option>
            </select>

            <button type="submit">Registrar</button>
          </form>
        </div>
      </main>

      {/* Footer */}
      <footer>
        <p>&copy; 2025 GameSearch. Todos los derechos reservados.</p>
      </footer>
    </div>
  );
}
