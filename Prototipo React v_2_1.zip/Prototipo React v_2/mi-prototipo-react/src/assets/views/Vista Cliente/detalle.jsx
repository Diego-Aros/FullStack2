import React from "react";
import "./style.css";
import "./styleProductos.css";

function Detalle() {
  return (
    <div>
      {/* Header */}
      <header>
        <div className="logo">
          <strong>GameSearch</strong>
        </div>

        <nav className="menu">
          <a href="paginaP.html">Inicio</a>
          <a href="productos.html">Productos</a>
          <a href="nosotros.html">Nosotros</a>
          <a href="comunidad.html">Blogs</a>
          <a href="contacto.html">Contacto</a>
        </nav>

        <div className="search-bar">
          <input type="text" placeholder="Buscar" />
        </div>

        <nav className="menu">
          <a href="ini_reg_usuario.html">Acceder</a>
          <a
            href="#"
            className="carrito"
            onClick={(e) => {
              e.preventDefault();
              console.log("Mostrar carrito");
              // aquí debería ir mostrarCarrito()
            }}
          >
            🛒 Carrito <span id="carrito-cantidad">0</span>
          </a>
        </nav>
      </header>
      {/* Header */}

      {/* Detalle del producto */}
      <div className="detalle-container">
        <div className="ruta-navegacion">
          <a href="productos.html">Productos</a> &gt;{" "}
          <span id="ruta-categoria">Categoría</span> &gt;{" "}
          <span id="ruta-producto">Nombre del Producto</span>
        </div>

        <div className="detalle-producto">
          <div className="imagen-container">
            <img
              id="imagen-producto"
              src=""
              alt="Producto"
              className="imagen-producto"
            />
          </div>

          <div className="info-producto">
            <h1 id="nombre-producto">Nombre del Producto</h1>
            <span id="plataforma-producto" className="plataforma-producto">
              Plataforma
            </span>
            <p id="precio-producto" className="precio-producto">
              $0 CLP
            </p>

            <div className="descripcion-producto">
              <p id="descripcion-producto">Descripción del producto...</p>
            </div>

            <button
              className="boton-carrito"
              onClick={() => console.log("Agregar al carrito")}
            >
              Agregar al carrito
            </button>
          </div>
        </div>

        {/* Productos relacionados */}
        <div className="productos-relacionados">
          <h2>Productos Relacionados</h2>
          <div className="relacionados-grid" id="relacionados-container">
            {/* Aquí se cargarán productos relacionados dinámicamente */}
          </div>
        </div>
      </div>
      {/* Detalle del producto */}

      {/* Carrito modal */}
      <div id="carrito-modal" className="modal">
        <div className="modal-contenido">
          <span
            className="cerrar"
            onClick={() => console.log("Cerrar carrito")}
          >
            &times;
          </span>
          <h2>Mi carrito de compras</h2>
          <div id="carrito-items">
            {/* Productos del carrito */}
          </div>
          <div className="carrito-total">
            <div className="cupon-descuento">
              <input
                type="text"
                id="codigo-descuento"
                placeholder="Código de descuento"
              />
              <button onClick={() => console.log("Aplicar descuento")}>
                Aplicar
              </button>
            </div>
            <div className="total-info">
              <p>
                Subtotal: <span id="subtotal">$0</span>
              </p>
              <p>
                Descuento: <span id="descuento">$0</span>
              </p>
              <p className="total">
                Total: <span id="total">$0</span>
              </p>
              <button
                className="btn-pagar"
                onClick={() => console.log("Pagar ahora")}
              >
                Pagar ahora
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* Carrito modal */}

      {/* Footer */}
      <footer>
        <p>&copy; 2025 GameSearch. Todos los derechos reservados.</p>
      </footer>
      {/* Footer */}
    </div>
  );
}

export default Detalle;
