import React from "react";
import "./style.css";
import "./styleContacto.css";

function Contacto() {
  // función para manejar envío de formulario
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Formulario enviado");
  };

  return (
    <div>
      {/* Header */}
      <header>
        <div className="logo">
          <strong>GameSearch</strong>
        </div>

        <nav className="menu">
          <a href="paginaP.html">Inicio</a>
          <a href="productos.html">Productos</a>
          <a href="nosotros.html">Nosotros</a>
          <a href="comunidad.html">Blogs</a>
          <a href="contacto.html" className="activo">Contacto</a>
        </nav>

        <div className="search-bar">
          <input type="text" placeholder="Buscar" />
        </div>

        <nav className="menu">
          <a href="ini_reg_usuario.html">Acceder</a>
        </nav>

        <a
          href="#"
          className="carrito"
          style={{ marginLeft: "20px" }}
          onClick={(e) => {
            e.preventDefault();
            console.log("Mostrar carrito");
          }}
        >
          🛒 Carrito <span id="carrito-cantidad">0</span>
        </a>
      </header>
      {/* Header */}

      {/* Main */}
      <main className="contacto-container">
        <section id="contacto">
          <h1>Contáctanos</h1>
          <p>
            ¿Tienes dudas, sugerencias o quieres vender tu colección completa?  
            En <strong>GameSearch</strong> estamos para ayudarte.
          </p>

          {/* Formulario */}
          <form className="form-contacto" onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="nombre">Nombre</label>
              <input type="text" id="nombre" name="nombre" required />
            </div>

            <div className="form-group">
              <label htmlFor="email">Correo electrónico</label>
              <input type="email" id="email" name="email" required />
            </div>

            <div className="form-group">
              <label htmlFor="mensaje">Mensaje</label>
              <textarea id="mensaje" name="mensaje" rows="5" required></textarea>
            </div>

            <button type="submit" className="btn-enviar">Enviar</button>
          </form>

          {/* Información extra */}
          <div className="info-extra">
            <h3>📍 Información de contacto</h3>
            <p><strong>Email:</strong> contacto@gamesearch.com</p>
            <p><strong>Teléfono:</strong> +56 9 1234 5678</p>
            <p><strong>Dirección:</strong> Santiago, Chile</p>
          </div>
        </section>
      </main>
      {/* Main */}

      {/* Footer */}
      <footer>
        <p>&copy; 2025 GameSearch. Todos los derechos reservados.</p>
      </footer>
    </div>
  );
}

export default Contacto;
