import React from "react";
import "./style.css";
import "./styleProductos.css";

function Productos() {
  return (
    <div>
      {/* Header */}
      <header>
        <div className="logo">
          <strong>GameSearch</strong>
        </div>

        <nav className="menu">
          <a href="paginaP.html">Inicio</a>
          <a href="productos.html">Productos</a>
          <a href="nosotros.html">Nosotros</a>
          <a href="comunidad.html">Blogs</a>
          <a href="contacto.html">Contacto</a>
        </nav>

        <div className="search-bar">
          <input type="text" placeholder="Buscar" />
        </div>

        <nav className="menu">
          <a href="ini_reg_usuario.html">Acceder</a>
          <a
            href="#"
            className="carrito"
            onClick={(e) => {
              e.preventDefault();
              console.log("Mostrar carrito");
              // aquí iría la función mostrarCarrito
            }}
          >
            🛒 Carrito <span id="carrito-cantidad">0</span>
          </a>
        </nav>
      </header>
      {/* Header */}

      {/* Catálogo */}
      <div className="catalogo">
        <h1>Nuestro catálogo de videojuegos</h1>

        {/* Filtros */}
        <div className="filtros">
          <select id="filtro-plataforma">
            <option value="todas">Todas las plataformas</option>
            <option value="ps5">PlayStation</option>
            <option value="xbox">Xbox</option>
            <option value="switch">Nintendo Switch</option>
            <option value="pc">PC</option>
          </select>

          <select id="filtro-categoria">
            <option value="todas">Todas las categorías</option>
            <option value="accion">Acción</option>
            <option value="aventura">Aventura</option>
            <option value="deportes">Deportes</option>
            <option value="rpg">RPG</option>
            <option value="estrategia">Estrategia</option>
          </select>

          <select id="filtro-orden">
            <option value="precio">Ordenar por: Precio</option>
            <option value="recientes">Más recientes</option>
            <option value="valorados">Mejor valorados</option>
          </select>

          <input type="text" id="busqueda" placeholder="Buscar por nombre..." />
        </div>

        {/* Contenedor de productos */}
        <div id="productos-container">
          {/* Aquí se cargarán dinámicamente los productos */}
        </div>
      </div>
      {/* Catálogo */}

      {/* Carrito modal */}
      <div id="carrito-modal" className="modal">
        <div className="modal-contenido">
          <span
            className="cerrar"
            onClick={() => console.log("Cerrar carrito")}
          >
            &times;
          </span>
          <h2>Mi carrito de compras</h2>
          <div id="carrito-items">
            {/* Productos del carrito */}
          </div>
          <div className="carrito-total">
            <div className="cupon-descuento">
              <input
                type="text"
                id="codigo-descuento"
                placeholder="Código de descuento"
              />
              <button onClick={() => console.log("Aplicar descuento")}>
                Aplicar
              </button>
            </div>
            <div className="total-info">
              <p>
                Subtotal: <span id="subtotal">$0</span>
              </p>
              <p>
                Descuento: <span id="descuento">$0</span>
              </p>
              <p className="total">
                Total: <span id="total">$0</span>
              </p>
              <button
                className="btn-pagar"
                onClick={() => console.log("Pagar ahora")}
              >
                Pagar ahora
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* Carrito modal */}

      {/* Footer */}
      <footer>
        <p>&copy; 2025 GameSearch. Todos los derechos reservados.</p>
      </footer>
    </div>
  );
}

export default Productos;
