import React from "react";
import "./style.css";
import "./stylePaginaP.css";

function PaginaP() {
  return (
    <div>
      {/* Header */}
      <header>
        <div className="logo">
          <strong>GameSearch</strong>
        </div>

        <nav className="menu">
          <a href="paginaP.html">Inicio</a>
          <a href="productos.html">Productos</a>
          <a href="nosotros.html">Nosotros</a>
          <a href="comunidad.html">Blogs</a>
          <a href="contacto.html">Contacto</a>
        </nav>

        <div className="search-bar">
          <input type="text" placeholder="Buscar" />
        </div>

        <nav className="menu">
          <a href="ini_reg_usuario.html">Acceder</a>
        </nav>

        <a
          href="#"
          className="carrito"
          onClick={(e) => {
            e.preventDefault();
            // Aquí deberías implementar mostrarCarrito
            console.log("Carrito clickeado");
          }}
          style={{ marginLeft: "20px" }}
        >
          🛒 Carrito <span id="carrito-cantidad">0</span>
        </a>
      </header>
      {/* Header */}

      {/* Contenido principal */}
      <main>
        {/* Sección Hero */}
        <section className="hero">
          <h1>Bienvenido a GameSearch</h1>
          <p>
            La comunidad global de <strong>coleccionistas de juegos físicos</strong>.{" "}
            Busca, compara, habla y compra con total seguridad.
          </p>
          <a href="productos.html" className="btn">
            Explorar Productos
          </a>
        </section>

        {/* Sección destacados */}
        <section className="destacados">
          <h2>Juegos destacados</h2>
          <div className="grid">
            <div className="card">
              <img src="img/Zelda.webp" alt="Juego 1" />
              <h3>The Legend of Zelda tears of the kingdom</h3>
              <p>Edición Standart, completa en caja.</p>
            </div>
            <div className="card">
              <img src="img/Final-Fantasy.webp" alt="Juego 2" />
              <h3>Final Fantasy XVI</h3>
              <p>Versión original para PS5.</p>
            </div>
            <div className="card">
              <img src="img/Animal-Crossing.webp" alt="Juego 3" />
              <h3>Animal Crossing: New Horizons</h3>
              <p>Cartucho original de Nintendo switch.</p>
            </div>
          </div>
        </section>

        {/* Sección comunidad */}
        <section className="comunidad">
          <h2>Nuestra comunidad</h2>
          <p>
            Comparte tus colecciones, escribe en nuestro{" "}
            <a href="comunidad.html">blog de coleccionistas</a> y conecta con
            otros apasionados por los juegos físicos.
          </p>
        </section>
      </main>
      {/* Contenido principal */}

      {/* Footer */}
      <footer>
        <p>&copy; 2025 GameSearch. Todos los derechos reservados.</p>
      </footer>
      {/* Footer */}
    </div>
  );
}

export default PaginaP;
